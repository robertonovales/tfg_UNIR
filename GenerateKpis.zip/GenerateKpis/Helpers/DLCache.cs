﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace GenerateKpis.Helpers
{
    public static class DLCache
    {
         public static string Download(string pUrl)
        {
            string strResult = null;

            // try to download file
            bool downloadErrorFlag = false;
            try
            {
                using (WebClient w = new WebClient())
                {
                    strResult = w.DownloadString(pUrl);
                }
            }
            catch (Exception ex)
            {
                downloadErrorFlag = true;
              //  Log.Error(string.Format("Couldn't download url: {0}", pUrl), ex);
            }

            /*   string file = Path.Combine(HostingEnvironment.ApplicationPhysicalPath, "App_Data", "dlcache", pUrl.GetHashString() + ".dat");

               try
               {
                   if (downloadErrorFlag)
                   {
                       if (File.Exists(file))
                       {
                           strResult = File.ReadAllText(file);
                       }
                       else
                       {
                           SalesService.Log.Warn(string.Format("No backup file for url: {0}", pUrl));
                       }
                   }
                   else
                   {
                       if (!Directory.Exists(file))
                       {
                           Directory.CreateDirectory(file);
                       }

                       File.WriteAllText(file, strResult);
                   }
               }
               catch (Exception ex)
               {
                   SalesService.Log.Error(string.Format("Couldn't access the cache for url: {0}", pUrl));
               }*/
            return strResult;

        }
    }
}
