﻿using GenerateKpis.Models.DAOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GenerateKpis.Models.Repositories;

namespace GenerateKpis
{
    class Program
    {
     
        static void Main(string[] args)
        {
            var kpiRepositories = new KpiRepository();
            if(args.Length == 0)
                kpiRepositories.GetTransactions();
            else
                kpiRepositories.GetTransactions(args[0]);
        }
    }
}
