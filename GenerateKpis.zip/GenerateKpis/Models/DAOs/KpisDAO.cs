﻿using GenerateKpis.Models.Entities;
using System;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using GenerateKpis.Helpers;

namespace GenerateKpis.Models.DAOs
{
    public class KpisDAO
    {
        private string _strUrl;
        private DataClasses1DataContext _db = new DataClasses1DataContext();
        public KpisDAO()
        {
            
        }

        public void GetAndSetDataSeries(string strDatePeriod = null)
        {
            var lstKpis = _db.KPIs.Where(x => x.Active == true).ToList();

            foreach (var _entity in lstKpis)
            {
                Kpi _resultAPI = new Kpi();
                _strUrl = ConfigurationManager.AppSettings["URLAPI"] + _entity.CodeToTake + "?date=" + (!String.IsNullOrWhiteSpace(strDatePeriod) ? strDatePeriod : ConfigurationManager.AppSettings["INITDATEPERIOD"] + ":" + DateTime.Now.ToString("yyyyMM") + "01");

                try
                {
                    var result = DLCache.Download(_strUrl);
                    //System.IO.File.WriteAllText(@"D:\Documentacion\kpi\log\resultItemJson" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".txt", result);
                    _resultAPI = JsonConvert.DeserializeObject<Kpi>(result);
                   
                    // insert in database
                    _db.ExecuteCommand("DELETE FROM imp.KPISerialReport WHERE KeyKpi=" + _entity.Id);
                    _db.SubmitChanges();

                    var lstPeriodValue = (from p in _db.KpisPeriodsKeys where p.KeyKpi == _entity.Id select new { periodSource = p.Period, periodInsert = p.Value }).ToList();
                  
                        foreach (var _data in _resultAPI.Data)
                        {
                            DateTime dtInsert = new DateTime();
                            if (_entity.Period.Equals("QUARTER"))
                            {
                                int intQuarter = lstPeriodValue != null ? lstPeriodValue.Where(y => y.periodSource == _data.FK_Periodo).Select(y => y.periodInsert).Single() : _data.FK_Periodo;
                                intQuarter = intQuarter == 0 ? _data.FK_Periodo : intQuarter;
                                dtInsert = new DateTime(_data.Anyo, (intQuarter - 1) * 3 + 1, 1);
                            }
                            else if (_entity.Period.Equals("MONTH"))
                            {
                                dtInsert = new DateTime(_data.Anyo, _data.FK_Periodo, 1);
                            }

                            KPISerialReport _serial = new KPISerialReport()
                            {
                                KeyKpi = _entity.Id,
                                CountryId = _entity.Zone,
                                InsertDate = dtInsert,
                                Measure = _data.Valor.ToString("f4")
                            };
                            _db.KPISerialReport.InsertOnSubmit(_serial);
                            _db.SubmitChanges();
                        }
                   
                }
                catch (Exception ex)
                {
                    // SalesService.Log.Error("Error parsing sales", ex);
                }
            }

        }
        /*
        public void GetAnsSetDataSeriesOLD()
        {
            var lstKpis = _db.KPIs.Where(x => x.Active == true).ToList();

            foreach (var _entity in lstKpis)
            {
                int page = 1;
                _strUrl = _entity.ApiUrl.Replace("[PAGE]", page.ToString()).Replace("[DATE]", ConfigurationManager.AppSettings["INITDATEPERIOD"] + ":" + DateTime.Now.ToString("yyyyMM") + "01");

                List <Kpi> lstTransactions = new List<Kpi>();
                List<Kpi> _tmplstTransactions = new List<Kpi>();
                try
                {
                    var result = DLCache.Download(_strUrl);
                    System.IO.File.WriteAllText(@"D:\Documentacion\kpi\log\resultItemJson" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".txt", result);
                    var ress = JsonConvert.DeserializeObject<Kpi>(result);
                    _tmplstTransactions = JsonConvert.DeserializeObject<List<Kpi>>(result);
                    if (!String.IsNullOrWhiteSpace(_entity.CodeToTake))
                        _tmplstTransactions = _tmplstTransactions.Where(x => x.COD.ToUpper().Equals(_entity.CodeToTake.ToUpper())).ToList();
                    lstTransactions.AddRange(_tmplstTransactions);
                    while (_tmplstTransactions != null && _tmplstTransactions.Count > 0)
                    {
                        _tmplstTransactions = new List<Kpi>();
                        page++;
                        _strUrl = _entity.ApiUrl.Replace("[PAGE]", page.ToString()).Replace("[DATE]", ConfigurationManager.AppSettings["INITDATEPERIOD"]+":"+DateTime.Now.ToString("yyyyMM")+"01");
                        result = DLCache.Download(_strUrl);
                        if (!string.IsNullOrWhiteSpace(result))
                        {
                            _tmplstTransactions.AddRange(JsonConvert.DeserializeObject<List<Kpi>>(result));
                            if (!String.IsNullOrWhiteSpace(_entity.CodeToTake))
                                _tmplstTransactions = _tmplstTransactions.Where(x => x.COD.ToUpper().Equals(_entity.CodeToTake.ToUpper())).ToList();
                            if (_tmplstTransactions.Count > 0)
                                lstTransactions.AddRange(_tmplstTransactions);
                        }
                    }

                    // insert in database
                    _db.ExecuteCommand("DELETE KPISerialReport WHERE KeyKpi="+_entity.Id);
                    _db.SubmitChanges();

                    var lstPeriodValue = (from p in _db.KpisPeriodsKeys where p.KeyKpi == _entity.Id select new { periodSource = p.Period, periodInsert = p.Value }).ToList();
                    foreach(var trans in lstTransactions)
                    {
                        foreach (var _data in trans.Data)
                        {
                            DateTime dtInsert = new DateTime();
                            if (_entity.Period.Equals("QUARTER"))
                            {
                                int intQuarter = lstPeriodValue != null ? lstPeriodValue.Where(y => y.periodSource == _data.FK_Periodo).Select(y => y.periodInsert).Single() : _data.FK_Periodo;
                                intQuarter = intQuarter == 0 ? _data.FK_Periodo : intQuarter;
                                dtInsert = new DateTime(_data.Anyo, (intQuarter - 1) * 3 + 1, 1);
                            }
                            else if (_entity.Period.Equals("MONTH"))
                            {
                                dtInsert = new DateTime(_data.Anyo, _data.FK_Periodo, 1);
                            }

                            KPISerialReport _serial = new KPISerialReport()
                            {
                                KeyKpi = _entity.Id,
                                CountryId = _entity.Zone,
                                InsertDate = dtInsert,
                                Measure = _data.Valor.ToString("f4")
                            };
                            _db.KPISerialReport.InsertOnSubmit(_serial);
                            _db.SubmitChanges();
                        }
                    }
                }
                catch (Exception ex)
                {
                    // SalesService.Log.Error("Error parsing sales", ex);
                }
            }
            
        }
        */
    }
}