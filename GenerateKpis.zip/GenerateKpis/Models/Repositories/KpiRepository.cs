﻿using GenerateKpis.Models.DAOs;
using GenerateKpis.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenerateKpis.Models.Repositories
{
    public class KpiRepository
    {
        public KpiRepository()
        {
        }

        public void GetTransactions(string strDatePeriod = null)
        {
            KpisDAO _kpisDAO = new KpisDAO();
            _kpisDAO.GetAndSetDataSeries(strDatePeriod);
        }
    }
}