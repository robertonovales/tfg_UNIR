﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenerateKpis.Models.Entities
{
    public class Kpi
    {
        public string COD { get; set; }
        //public string Nombre { get; set; }
        public string FK_Unidad { get; set; }
        public string FK_Escala { get; set; }
        public List<KpiSerie> Data { get; set; }
    }

    public class KpiSerie
    {
        public string FK_TipoDato { get; set; }
        public int FK_Periodo { get; set; }
        public int Anyo { get; set; }
        public decimal Valor { get; set; }
        public bool Secreto { get; set; }
    }
}
